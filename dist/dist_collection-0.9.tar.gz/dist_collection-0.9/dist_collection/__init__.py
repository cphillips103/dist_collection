""" 
Init for python distribution package

"""
from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial
from .Poissondistribution import Poisson